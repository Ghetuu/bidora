import os
import logging
import requests

logger = logging.getLogger(__name__)

SMS_MODE = os.getenv("BID_SMS_MODE", "simulation").lower()

TEXTBEE_API_KEY = os.getenv("TEXTBEE_API_KEY", "").strip()
TEXTBEE_DEVICE_ID = os.getenv("TEXTBEE_DEVICE_ID", "").strip()

TEXTBEE_API_URL = "https://api.textbee.dev/api/v1/gateway/send-sms"


def mask_mobile_number(mobile):
    mobile = str(mobile or "")

    if len(mobile) <= 4:
        return "****"

    return "*" * (len(mobile) - 4) + mobile[-4:]


def normalize_mobile_number(mobile):
    """
    Convert an Indian 10-digit mobile number to +91 format.
    Also accept numbers already written in international format.
    """
    mobile = str(mobile or "").strip()

    # Remove spaces and common formatting characters.
    mobile = mobile.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")

    if mobile.startswith("+"):
        return mobile

    if mobile.startswith("91") and len(mobile) == 12:
        return "+" + mobile

    if len(mobile) == 10 and mobile.isdigit():
        return "+91" + mobile

    raise ValueError("Invalid mobile number. Use a 10-digit Indian number or international format.")


def send_sms(mobile, message):
    """
    Send a seller notification through TextBee or simulate it locally.
    """

    if not mobile or not message:
        logger.error("SMS not sent: recipient mobile or message is missing.")
        return False

    # Keep simulation available for local development.
    if SMS_MODE == "simulation":
        logger.info(
            "[BIDORA SMS SIMULATION] recipient=%s message=%s",
            mask_mobile_number(mobile),
            message,
        )
        return True

    if SMS_MODE != "textbee":
        logger.error("Unsupported BID_SMS_MODE: %s", SMS_MODE)
        return False

    if not TEXTBEE_API_KEY:
        logger.error("TEXTBEE_API_KEY is missing from the backend environment.")
        return False

    try:
        recipient = normalize_mobile_number(mobile)

        payload = {
            "recipients": [recipient],
            "message": str(message),
        }

        if TEXTBEE_DEVICE_ID:
            payload["deviceId"] = TEXTBEE_DEVICE_ID

        headers = {
            "x-api-key": TEXTBEE_API_KEY,
            "Content-Type": "application/json",
        }

        response = requests.post(
            TEXTBEE_API_URL,
            headers=headers,
            json=payload,
            timeout=20,
        )

        if response.status_code != 200:
            logger.error(
                "TextBee request failed. HTTP status: %s, response: %s",
                response.status_code,
                response.text[:500],
            )
            return False

        result = response.json()
        data = result.get("data", {})

        if data.get("success") is True:
            logger.info(
                "TextBee accepted SMS for recipient=%s batch_id=%s",
                mask_mobile_number(recipient),
                data.get("smsBatchId"),
            )
            return True

        logger.error("TextBee did not accept SMS: %s", result)
        return False

    except ValueError as exc:
        logger.error("SMS recipient error: %s", exc)
        return False

    except requests.RequestException as exc:
        logger.error("TextBee network error: %s", exc)
        return False

    except Exception:
        logger.exception("Unexpected error while sending SMS.")
        return False