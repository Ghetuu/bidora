import asyncio
import logging
import os
from datetime import datetime
from decimal import Decimal

from sqlalchemy import select

from app.database import SessionLocal
from app.models.bid_sms_notification import BidSMSNotification
from app.services.sms_service import send_sms

logger = logging.getLogger(__name__)

POLL_INTERVAL_SECONDS = 5
MAX_ATTEMPTS = 3


async def process_pending_sms():
    """
    Process due seller SMS notifications.

    Uses a separate database session for each notification.
    """

    db = SessionLocal()

    try:
        now = datetime.utcnow()

        notifications = (
            db.query(BidSMSNotification)
            .filter(
                BidSMSNotification.status == "PENDING",
                BidSMSNotification.scheduled_at <= now,
            )
            .order_by(BidSMSNotification.scheduled_at.asc())
            .limit(50)
            .all()
        )

        for notification in notifications:
            try:
                notification.status = "PROCESSING"
                db.commit()

                success = send_sms(
                    notification.recipient_mobile,
                    notification.message,
                )

                if success:
                    notification.status = "SENT"
                    notification.sent_at = datetime.utcnow()
                    notification.last_error = None
                else:
                    notification.attempt_count += 1
                    notification.last_error = "SMS provider did not confirm success."

                    if notification.attempt_count >= MAX_ATTEMPTS:
                        notification.status = "FAILED"
                    else:
                        notification.status = "PENDING"

                db.commit()

            except Exception as exc:
                db.rollback()

                logger.exception(
                    "Failed to process seller SMS notification ID %s",
                    notification.id,
                )

                # Reload the notification after rollback.
                failed_notification = (
                    db.query(BidSMSNotification)
                    .filter(BidSMSNotification.id == notification.id)
                    .first()
                )

                if failed_notification:
                    failed_notification.attempt_count += 1
                    failed_notification.last_error = str(exc)[:500]

                    if failed_notification.attempt_count >= MAX_ATTEMPTS:
                        failed_notification.status = "FAILED"
                    else:
                        failed_notification.status = "PENDING"
                        failed_notification.scheduled_at = datetime.utcnow()

                    db.commit()

    finally:
        db.close()


async def bid_sms_worker():
    """Continuously process due seller SMS notifications."""

    logger.info("Bidora seller SMS worker started.")

    while True:
        try:
            await process_pending_sms()
        except asyncio.CancelledError:
            logger.info("Bidora seller SMS worker stopped.")
            raise
        except Exception:
            logger.exception("Unexpected error in Bidora seller SMS worker.")

        await asyncio.sleep(POLL_INTERVAL_SECONDS)